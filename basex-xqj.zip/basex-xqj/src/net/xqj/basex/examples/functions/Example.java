package net.xqj.basex.examples.functions;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQResultSequence;
import net.xqj.basex.BaseXXQDataSource;


    public class Example{
      public static void main(String[] args) throws XQException{
        XQDataSource xqs = new BaseXXQDataSource();
        xqs.setProperty("serverName", "localhost");
        xqs.setProperty("port", "1984");
    
        // Change USERNAME and PASSWORD values
        XQConnection conn = xqs.getConnection("admin", "admin");
    
        XQExpression xqe =
        conn.createExpression();
    
       //XQResultSequence rs = xqe.executeQuery("for $bondia in collection('mondial') //country return $bondia");
       XQResultSequence rs = xqe.executeQuery("//country");
    
        while(rs.next())
          System.out.println(rs.getItemAsString(null));
    
        conn.close();
      }
    }
